let num = 100; //переменная- число
let text ="text"; //переменная-текст
let object = { //переменная - объект
	key1:"что-то" ,//ключ со значением
	key2:"что-то еще"
}
onclick = function(){} // клики(нажатие) на различные html элементы

style.height = "100px"; //меняет различные css свойства элементов
document.querySelector() // находит нужный элемент в html по классу 
alert() //всплывающее окно на странице
innerHTML = num; //заменяет содержимое элемента
let proverka = function() {//создание функции
	alert('privet')
}
setTimeout(proverka,1000) //таймер
document.querySelectorAll() //находит все элементы с одинаковым классом

let array = ["lol","kek",21,"hello"]; //массив
array[0];

for(let index = 0; index<2; index = index + 1){
	alert(index);
}